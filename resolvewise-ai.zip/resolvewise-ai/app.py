import os
import streamlit as st
from dotenv import load_dotenv
from decider_client import get_decision, DecisionError
from policy import apply_policy
from bedrock_client import generate_response, BedrockError

load_dotenv()
st.set_page_config(page_title="ResolveWise AI", page_icon="🧭", layout="centered")
st.title("🧭 ResolveWise AI")
st.caption("Customer-support triage with a typed decision pattern and Amazon Bedrock")

mode = os.getenv("DECIDER_MODE", "demo").strip().lower()
if mode == "demo":
    st.warning("DEMO MODE: illustrative local rules only; this is not a real Decider 2B result.")
elif mode == "decider_api":
    st.success("Real endpoint mode selected. Confirm the endpoint calls the actual Decider 2B model.")
else:
    st.error("DECIDER_MODE must be demo or decider_api.")

with st.form("support_form"):
    message = st.text_area("Customer support request",
        placeholder="Example: I was charged twice for the same order.", height=140)
    urgent = st.checkbox("Customer says the issue is urgent")
    submitted = st.form_submit_button("Analyze request", type="primary")

if submitted:
    if not message.strip():
        st.error("Enter a customer support request first.")
        st.stop()
    try:
        decision = get_decision(message.strip())
        policy = apply_policy(decision["choice"], float(decision["confidence"]),
                              message, urgent, float(os.getenv("CONFIDENCE_THRESHOLD", "0.65")))
    except (DecisionError, ValueError, KeyError) as exc:
        st.error(f"Decision failed safely: {exc}")
        st.stop()

    st.subheader("Decision")
    c1, c2 = st.columns(2)
    c1.metric("Category", decision["choice"])
    c2.metric("Confidence", f'{decision["confidence"]:.0%}')
    st.write("**Explanation:**", decision.get("reason", "No explanation returned."))
    st.write("**Priority:**", policy["priority"])
    st.write("**Escalate to human:**", "Yes" if policy["escalate"] else "No")
    if policy["escalate"]:
        st.write("**Escalation reason:**", policy["escalation_reason"])
    if decision.get("mode") == "demo":
        st.info("This result is from demo mode, not Strands Decider 2B.")

    if st.button("Draft response with Amazon Bedrock"):
        try:
            with st.spinner("Calling Amazon Bedrock..."):
                draft = generate_response(message, decision["choice"],
                                          policy["priority"], policy["escalate"])
            st.subheader("Bedrock response draft")
            st.write(draft)
            st.caption("Draft only. Review before sending; no message or refund is executed.")
        except BedrockError as exc:
            st.error(str(exc))
