# ResolveWise AI: Confidence-aware support triage with Strands Decider 2B

> Draft template. Publish only after the real Decider 2B and Bedrock paths have been run. Replace every bracketed item with truthful details.

## Problem
Support requests must be categorized and prioritized before a helpful response is drafted. ResolveWise separates a constrained triage decision from response generation.

## What it does
The agent asks Strands Decider 2B to choose one typed category: billing, technical, account access, order status, or other. The app validates the output and escalates low-confidence or high-risk cases. Amazon Bedrock drafts a response without claiming actions have already occurred.

## Reusable pattern
The repository's `patterns/support_triage.md` documents the typed question, options, wiring, and low-confidence behavior.

## Safety
Customer messages are untrusted input. The agent does not issue refunds, modify accounts, or send messages. Sensitive cases require human review.

## Evaluation
Use a labeled test set and report measured accuracy, confusion matrix, escalation recall, latency, and cost. Do not invent benchmark results.

- Decider deployment: [fill in]
- Bedrock model and region: [fill in]
- Test set size/source: [fill in]
- Accuracy and escalation metrics: [measured values]
- Latency/cost: [measured values or omit]

Repository: [PUBLIC GITHUB URL]
Demo video: [PUBLIC VIDEO URL]

Tags: `#strands-decider-2b` `#policy`
