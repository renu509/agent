# ResolveWise AI

ResolveWise AI is a customer-support triage agent scaffold. It is designed to use a real Strands Decider 2B inference endpoint for a constrained decision and Amazon Bedrock for response generation.

**Important:** `DECIDER_MODE=demo` is for UI testing only. It does not use Decider 2B and does not qualify for the hackathon. Before submitting, configure and test a real Decider 2B service and Bedrock access.

## Architecture
1. Accept a customer-support message.
2. Ask Decider 2B to choose one typed category: `billing`, `technical`, `account_access`, `order_status`, or `other`.
3. Validate the output and escalate low-confidence/high-risk cases.
4. Use Amazon Bedrock to draft a response. No refunds, account changes, or messages are executed.

## Windows setup
```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
streamlit run app.py
```
If `py -3.11` is unavailable, install Python 3.11 from https://www.python.org/downloads/ and enable the PATH option.

## Bedrock configuration
- Configure AWS credentials with the AWS CLI (`aws configure`) or an AWS profile.
- In the AWS console, enable access to a supported model in your selected region.
- Set `AWS_REGION` and `BEDROCK_MODEL_ID` in `.env`.
- Ensure your IAM identity can invoke that model.
- Check pricing before testing; model usage may incur charges.

## Real Decider 2B endpoint
Set `DECIDER_MODE=decider_api` and `DECIDER_ENDPOINT` to an endpoint that actually serves Strands Decider 2B. The adapter expects this JSON request:
```json
{
  "question": "Which category best matches this support request?",
  "context": "Customer says they were charged twice.",
  "options": ["billing", "technical", "account_access", "order_status", "other"]
}
```
Expected JSON response:
```json
{"choice":"billing","confidence":0.92,"reason":"The customer describes a duplicate charge."}
```
The service behind this endpoint must call the real Decider 2B model. Adapt `decider_client.py` to the official serving API you deploy; do not fake the model call.

Official resources:
- https://github.com/strands-labs/strands-decider
- https://docs.aws.amazon.com/bedrock/latest/userguide/getting-started.html

## Files
- `app.py`: Streamlit UI
- `decider_client.py`: typed decision adapter
- `policy.py`: explicit escalation policy
- `bedrock_client.py`: Bedrock response drafting
- `patterns/support_triage.md`: reusable decision pattern
- `ARTICLE_DRAFT.md`: Builder Center article template
- `VIDEO_SCRIPT.md`: demo outline
- `tests/test_policy.py`: policy tests

## Safety
Customer text is untrusted input. The app only drafts responses; it does not issue refunds, change accounts, or send messages. Human review is required for high-risk and low-confidence cases. Do not use real personal customer data in a public demo.

## Submission checklist
- [ ] Real Decider 2B decision tested
- [ ] Amazon Bedrock response generation tested
- [ ] Public repository with OSI-approved license
- [ ] Builder Center article published
- [ ] Public demo video under 3 minutes published
- [ ] Tags: `#strands-decider-2b` and `#policy`
- [ ] Repository, article, and video links submitted
