import unittest
from policy import apply_policy

class PolicyTests(unittest.TestCase):
    def test_low_confidence_escalates(self):
        r = apply_policy("other", 0.2, "I need help", threshold=0.65)
        self.assertTrue(r["escalate"])
        self.assertEqual(r["priority"], "needs_review")

    def test_duplicate_charge_escalates(self):
        r = apply_policy("billing", 0.95, "I was charged twice")
        self.assertTrue(r["escalate"])
        self.assertEqual(r["priority"], "critical")

    def test_order_status(self):
        r = apply_policy("order_status", 0.95, "Where is my order?")
        self.assertFalse(r["escalate"])
        self.assertEqual(r["priority"], "normal")

if __name__ == "__main__":
    unittest.main()
