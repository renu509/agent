HIGH_RISK_TERMS = [
    "fraud", "stolen", "unauthorized", "identity theft", "data breach",
    "charged twice", "duplicate charge", "can't access my money",
]

def apply_policy(category: str, confidence: float, customer_message: str,
                 urgent: bool = False, threshold: float = 0.65) -> dict:
    """Inspectable policy layer; never executes customer-account actions."""
    text = customer_message.lower()
    high_risk = any(term in text for term in HIGH_RISK_TERMS)
    low_confidence = confidence < threshold
    escalate = low_confidence or high_risk or urgent or category in {"billing", "account_access"}

    if high_risk:
        priority, reason = "critical", "Potential fraud, unauthorized activity, or financial harm."
    elif urgent:
        priority, reason = "high", "Customer marked the issue urgent."
    elif low_confidence:
        priority, reason = "needs_review", "Decision confidence is below the configured threshold."
    elif category in {"billing", "account_access"}:
        priority, reason = "high", "Sensitive billing or account-access category."
    else:
        priority, reason = "normal", ""
    return {"priority": priority, "escalate": escalate,
            "escalation_reason": reason if escalate else "",
            "high_risk": high_risk, "low_confidence": low_confidence}
